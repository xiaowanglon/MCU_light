#ifndef __KEY_H__
#define __KEY_H__

sbit LED_mode=P2^0;										//LED�ƴ�������P2.0
sbit LED1 = P2^1;
sbit LED2 = P2^2;
sbit LED3 = P2^3;
sbit LED4 = P2^4;

sbit IR_door_back = P3^2;
sbit IR_door_forw = P3^3;
unsigned char Key();

#endif
